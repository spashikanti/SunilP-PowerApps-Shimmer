/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./PowerShimmerUltraLight/index.ts"
/*!*****************************************!*\
  !*** ./PowerShimmerUltraLight/index.ts ***!
  \*****************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   PowerShimmerUltraLight: () => (/* binding */ PowerShimmerUltraLight)\n/* harmony export */ });\n/** Normalize color to #RRGGBB for use in CSS. Accepts hex with/without # or leaves valid hex unchanged. */\nfunction normalizeColor(value, fallback) {\n  if (value == null || typeof value !== \"string\") return fallback;\n  var trimmed = value.trim();\n  if (trimmed.startsWith(\"#\") && /^#[0-9A-Fa-f]{3,8}$/.test(trimmed)) return trimmed;\n  if (/^[0-9A-Fa-f]{6}$/.test(trimmed)) return \"#\" + trimmed;\n  if (/^[0-9A-Fa-f]{3}$/.test(trimmed)) return \"#\" + trimmed.split(\"\").map(c => c + c).join(\"\");\n  return fallback;\n}\nclass PowerShimmerUltraLight {\n  constructor() {\n    this.resizeObserver = null;\n    this.resizeCallback = null;\n    // Intentional empty constructor\n  }\n  init(context, notifyOutputChanged, state, container) {\n    this.container = container;\n    this.container.style.position = \"relative\";\n    this.container.style.width = \"100%\";\n    this.container.style.height = \"100%\";\n    //this.container.style.minHeight = \"1px\";\n    this.container.style.boxSizing = \"border-box\";\n    this.container.style.border = \"none\";\n    this.container.style.outline = \"none\";\n    this.container.style.boxShadow = \"none\";\n    // 1. Create the outer container\n    this.shimmerElement = document.createElement(\"div\");\n    this.shimmerElement.classList.add(\"shimmer-container\");\n    this.shimmerElement.style.border = \"none\";\n    this.shimmerElement.style.outline = \"none\";\n    this.shimmerElement.style.boxShadow = \"none\";\n    // 2. Create the inner animating element\n    this.innerElement = document.createElement(\"div\");\n    this.innerElement.classList.add(\"shimmer-element\");\n    // Assemble\n    this.shimmerElement.appendChild(this.innerElement);\n    this.container.appendChild(this.shimmerElement);\n    // Initial render\n    this.updateView(context);\n  }\n  updateView(context) {\n    var _a, _b, _c, _d, _e, _f, _g;\n    var bgRaw = (_a = context.parameters.BackgroundColor) === null || _a === void 0 ? void 0 : _a.raw;\n    var highlightRaw = (_b = context.parameters.HighlightColor) === null || _b === void 0 ? void 0 : _b.raw;\n    var speed = Math.max(0, (_d = (_c = context.parameters.AnimationSpeed) === null || _c === void 0 ? void 0 : _c.raw) !== null && _d !== void 0 ? _d : 1.5);\n    var shape = (_e = context.parameters.ShapeType) === null || _e === void 0 ? void 0 : _e.raw;\n    var cornerRadius = Math.max(0, (_g = (_f = context.parameters.CornerRadius) === null || _f === void 0 ? void 0 : _f.raw) !== null && _g !== void 0 ? _g : 8);\n    var validBg = normalizeColor(bgRaw, \"#F3F2F1\");\n    var validHighlight = normalizeColor(highlightRaw, \"#E1E1E1\");\n    var isCircle = String(shape) === \"1\";\n    if (!this.innerElement || !this.shimmerElement) return;\n    // Apply gradient (colors) with !important so they always take effect\n    var gradient = \"linear-gradient(90deg, \".concat(validBg, \" 25%, \").concat(validHighlight, \" 50%, \").concat(validBg, \" 75%)\");\n    this.innerElement.style.setProperty(\"background-image\", gradient, \"important\");\n    this.innerElement.style.setProperty(\"animation-duration\", \"\".concat(speed, \"s\"), \"important\");\n    // Base background so the chosen color is visible even before animation\n    this.shimmerElement.style.setProperty(\"background-color\", validBg, \"important\");\n    if (isCircle) {\n      this.innerElement.className = \"shimmer-element shimmer-circle\";\n      this.innerElement.style.removeProperty(\"width\");\n      this.innerElement.style.removeProperty(\"height\");\n      this.innerElement.style.removeProperty(\"border-radius\");\n      this.updateCircleSize();\n      this.observeResize(() => this.updateCircleSize());\n      this.shimmerElement.style.width = \"\";\n      this.shimmerElement.style.height = \"\";\n    } else {\n      this.unobserveResize();\n      var isRounded = String(shape) === \"2\";\n      this.innerElement.className = isRounded ? \"shimmer-element shimmer-rectangle shimmer-rectangle-rounded\" : \"shimmer-element shimmer-rectangle\";\n      this.innerElement.style.removeProperty(\"min-width\");\n      this.innerElement.style.removeProperty(\"min-height\");\n      this.innerElement.style.setProperty(\"width\", \"100%\", \"important\");\n      this.innerElement.style.setProperty(\"height\", \"100%\", \"important\");\n      // Apply configurable corner radius for rounded rectangle, 0 for sharp rectangle\n      var radiusForRounded = isRounded ? \"\".concat(cornerRadius, \"px\") : \"0px\";\n      this.innerElement.style.setProperty(\"border-radius\", radiusForRounded, \"important\");\n      this.updateRectangleSize();\n      this.observeResize(() => this.updateRectangleSize());\n      // In case container isn't laid out yet (e.g. test harness), re-measure after paint\n      requestAnimationFrame(() => this.updateRectangleSize());\n    }\n  }\n  updateRectangleSize() {\n    if (!this.container || !this.shimmerElement) return;\n    var root = this.container.closest(\".control-container\");\n    var el = root || this.container;\n    var w = el.offsetWidth || el.clientWidth || 100;\n    var h = el.offsetHeight || el.clientHeight || 40;\n    if (root) {\n      this.container.style.width = \"\".concat(w, \"px\");\n      this.container.style.height = \"\".concat(h, \"px\");\n    }\n    this.shimmerElement.style.setProperty(\"width\", \"\".concat(w, \"px\"), \"important\");\n    this.shimmerElement.style.setProperty(\"height\", \"\".concat(h, \"px\"), \"important\");\n  }\n  updateCircleSize() {\n    if (!this.container || !this.innerElement) return;\n    var root = this.container.closest(\".control-container\");\n    var el = root || this.container;\n    var w = el.offsetWidth || el.clientWidth || 100;\n    var h = el.offsetHeight || el.clientHeight || 100;\n    var size = Math.min(w, h);\n    if (root) {\n      this.container.style.width = \"\".concat(w, \"px\");\n      this.container.style.height = \"\".concat(h, \"px\");\n    }\n    this.innerElement.style.setProperty(\"width\", \"\".concat(size, \"px\"), \"important\");\n    this.innerElement.style.setProperty(\"height\", \"\".concat(size, \"px\"), \"important\");\n    this.innerElement.style.setProperty(\"min-width\", \"\".concat(size, \"px\"), \"important\");\n    this.innerElement.style.setProperty(\"min-height\", \"\".concat(size, \"px\"), \"important\");\n  }\n  observeResize(callback) {\n    this.unobserveResize();\n    this.resizeCallback = callback;\n    if (!this.container || typeof ResizeObserver === \"undefined\") return;\n    this.resizeObserver = new ResizeObserver(() => {\n      var _a;\n      return (_a = this.resizeCallback) === null || _a === void 0 ? void 0 : _a.call(this);\n    });\n    var root = this.container.closest(\".control-container\") || this.container;\n    this.resizeObserver.observe(root);\n  }\n  unobserveResize() {\n    if (this.resizeObserver && this.container) {\n      this.resizeObserver.unobserve(this.container);\n      this.resizeObserver = null;\n    }\n    this.resizeCallback = null;\n  }\n  getOutputs() {\n    return {};\n  }\n  destroy() {\n    this.unobserveResize();\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PowerShimmerUltraLight/index.ts?\n}");

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./PowerShimmerUltraLight/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('SunilP.PowerShimmerUltraLight', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PowerShimmerUltraLight);
} else {
	var SunilP = SunilP || {};
	SunilP.PowerShimmerUltraLight = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PowerShimmerUltraLight;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}